旅のしおり Android 项目

本项目通过 GitHub Actions 在云端编译 Android APK，无需本地安装 Android Studio。

网页内容位于：app/src/main/assets/index.html
应用包名：com.example.fukuokatravel
应用显示名称：旅のしおり
当前版本：1.1.0（旅行首页与档案结构更新）

说明：
1. 本项目是 WebView Android 外壳，旅行手册内容在本地 assets 中。
2. 首页采用“最近旅行”布局，保留福冈原有旅行内容，并为东京独立旅行手册预留档案入口。
3. 福冈行程、账本、清单与备忘继续使用原有 fukuoka_ 数据键，升级时不会主动清空。
4. 行程编辑与数据保存由 Android System WebView 提供。
5. 地图和外部导航需要网络连接。
6. GitHub Actions 输出 debug APK，可在自己的手机上安装测试。
