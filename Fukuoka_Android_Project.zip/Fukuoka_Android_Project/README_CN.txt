旅のしおり · 福冈 Android 项目

本项目通过 GitHub Actions 在云端编译 Android APK，无需本地安装 Android Studio。

构建环境：JDK 17、Gradle 8.9、Android Gradle Plugin 8.7.3、Android SDK 35。

网页内容位于：app/src/main/assets/index.html
应用包名：com.example.fukuokatravel
当前版本：1.0.0

说明：
1. 本项目是 WebView Android 外壳，旅行手册内容在本地 assets 中。
2. 行程编辑与 localStorage 数据保存由 Android System WebView 提供。
3. 地图和外部导航需要网络连接。
4. 首版未配置应用签名密钥；GitHub Actions 输出 debug APK，可在自己的手机上安装测试。
5. 返程抵达上海时间已按用户确认修正为 12:50。
